"""
Inventory & Bill Generation System
-----------------------------------
This project demonstrates concepts from the lab manual:
- Dictionaries (Inventory storage)
- Lists (Cart/Order tracking)
- Functions (Bill calculation)
- File Handling (Saving receipts)
- Error Handling (Input validation)
- Control Flow (Loops and conditionals)
"""

import datetime

# 1. Inventory stored in a Dictionary (Concept 8a)
inventory = {
    "Coffee": 50.0,
    "Tea": 30.0,
    "Sandwich": 80.0,
    "Cake": 120.0,
    "Juice": 60.0,
    "Pasta": 150.0
}

def display_menu():
    print("\n--- CAFE MENU ---")
    print(f"{'Item':<15} {'Price (INR)':<10}")
    print("-" * 25)
    for item, price in inventory.items():
        print(f"{item:<15} {price:<10}")
    print("-" * 25)

def generate_bill(cart):
    # 2. Functional Programming concepts (Concept 9a)
    total = sum(item['price'] * item['quantity'] for item in cart)
    tax = total * 0.05  # 5% GST
    grand_total = total + tax
    return total, tax, grand_total

def save_receipt(cart, total, tax, grand_total):
    # 3. File Handling (Concept 10a)
    filename = f"receipt_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(filename, "w") as f:
            f.write("--- CAFE BILL RECEIPT ---\n")
            f.write(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("-" * 30 + "\n")
            f.write(f"{'Item':<15} {'Qty':<5} {'Price':<10}\n")
            for item in cart:
                f.write(f"{item['name']:<15} {item['quantity']:<5} {item['price']*item['quantity']:<10.2f}\n")
            f.write("-" * 30 + "\n")
            f.write(f"Subtotal:    INR {total:.2f}\n")
            f.write(f"GST (5%):    INR {tax:.2f}\n")
            f.write(f"GRAND TOTAL: INR {grand_total:.2f}\n")
            f.write("-" * 30 + "\n")
            f.write("Thank you for visiting!\n")
        print(f"\nReceipt saved successfully as {filename}")
    except Exception as e:
        print(f"Error saving receipt: {e}")

def main():
    cart = []
    print("Welcome to the Smart Cafe System!")
    
    while True:
        display_menu()
        # 4. Error Handling (Concept 11b)
        item_choice = input("\nEnter item name to add to cart (or 'done' to finish): ").title()
        
        if item_choice == 'Done':
            break
        
        if item_choice in inventory:
            try:
                qty = int(input(f"Enter quantity for {item_choice}: "))
                if qty <= 0:
                    print("Quantity must be positive!")
                    continue
                # 5. List of Dictionaries (Concept 6a/8a combined)
                cart.append({
                    "name": item_choice,
                    "price": inventory[item_choice],
                    "quantity": qty
                })
                print(f"Added {qty} x {item_choice} to cart.")
            except ValueError:
                print("Invalid input! Please enter a numeric value for quantity.")
        else:
            print("Item not found in menu. Please try again.")

    if cart:
        total, tax, grand_total = generate_bill(cart)
        print("\n--- FINAL BILL ---")
        for item in cart:
            print(f"{item['name']}: {item['quantity']} x {item['price']} = {item['quantity']*item['price']}")
        print(f"Subtotal: INR {total}")
        print(f"GST (5%): INR {tax}")
        print(f"Total Amount: INR {grand_total}")
        
        save_confirm = input("\nWould you like to save the receipt? (yes/no): ").lower()
        if save_confirm == 'yes':
            save_receipt(cart, total, tax, grand_total)
    else:
        print("Cart is empty. Goodbye!")

if __name__ == "__main__":
    main()
