import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# Data from our inventory system
items = ["Tea", "Coffee", "Juice", "Sandwich", "Cake", "Pasta"]
prices = [30, 50, 60, 80, 120, 150]

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Define positions for the bars
x = np.arange(len(items))
y = np.zeros(len(items))
z = np.zeros(len(items))

# Define dimensions for the bars
dx = 0.5 * np.ones(len(items))
dy = 0.5 * np.ones(len(items))
dz = prices

# Color mapping (gradient based on price)
colors = plt.cm.viridis(np.linspace(0, 1, len(items)))

# Create 3D bars
ax.bar3d(x, y, z, dx, dy, dz, color=colors, alpha=0.8)

# Customize the chart
ax.set_xticks(x + 0.25)
ax.set_xticklabels(items)
ax.set_xlabel('Menu Items')
ax.set_ylabel('Category')
ax.set_zlabel('Price (INR)')
ax.set_title('3D Inventory Price Model')

# Add a text box explaining the "Pyramid" concept
# Higher price items are at the top of the price hierarchy
plt.savefig('visual_model.png')
print("3D Visual Model saved as visual_model.png")
