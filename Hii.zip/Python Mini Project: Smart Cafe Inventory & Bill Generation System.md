# Python Mini Project: Smart Cafe Inventory & Bill Generation System

## 1. Project Overview
The **Smart Cafe Inventory & Bill Generation System** is a Python-based mini project designed to demonstrate the core programming concepts learned during the lab sessions. It simulates a cafe environment where users can view a menu, add items to a cart, calculate the total bill including taxes, and save the final receipt to a text file.

## 2. Python Concepts Implemented
This project successfully integrates multiple concepts from the lab manual:

*   **Dictionaries (Concept 8a):** The cafe's inventory (items and prices) is stored using a dictionary, allowing for efficient lookups.
*   **Lists (Concept 6a/6b):** The user's order (cart) is managed using a list of dictionaries, where each dictionary represents an ordered item, its price, and quantity.
*   **Functional Programming (Concept 9a):** The bill calculation logic (subtotal, tax, and grand total) is encapsulated within a dedicated function `generate_bill()`.
*   **File Handling (Concept 10a):** The system generates a formatted receipt and writes it to a `.txt` file with a unique timestamp.
*   **Error Handling (Concept 11b):** `try-except` blocks are used to handle invalid user inputs (e.g., entering letters instead of numbers for quantity) to prevent the program from crashing.
*   **Control Flow (Concepts 2a, 3a, 4a):** `while` loops are used to keep the ordering process active until the user is done, and `if-else` statements are used for input validation.

## 3. Visual Models
To explain the project concept and working, two visual models have been prepared:

### 3.1. 3D Inventory Price Model
This 3D bar chart visualizes the cafe's inventory. The x-axis represents the menu items, and the z-axis (height) represents their respective prices. The color gradient helps distinguish between lower-priced items (like Tea) and higher-priced items (like Pasta).

![3D Inventory Price Model](https://private-us-east-1.manuscdn.com/sessionFile/hEvqTFxwfjACfqQbSyJTeg/sandbox/CCahtbmt50DU52xhM90PJ0-images_1780243148383_na1fn_L2hvbWUvdWJ1bnR1L3Zpc3VhbF9tb2RlbA.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvaEV2cVRGeHdmakFDZnFRYlN5SlRlZy9zYW5kYm94L0NDYWh0Ym10NTBEVTUyeGhNOTBQSjAtaW1hZ2VzXzE3ODAyNDMxNDgzODNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzWnBjM1ZoYkY5dGIyUmxiQS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=Iwp~JY8eHjK8aK2FcNm8Ort-MqEgZ4zTKYkzIcdb5PRCmLp6TK3WUYi0MYB-4nuzgRJDM2pruDZ5g0LB6K78At3WGPNZQQMCLBmfYNFiNTjLKA4BBQvwsCrBsLahvYNvR20n6rBeyCgADyb4Mi-uHCtpARYxkvMChgJ1ufC-exdeEEQqtopbYdsnJOlqagZxkxUjMH8S65suSgMYJyqvhffGeMX8DTXt1xbetnAnlGIZl-JTvnO4hs4DdMSLZDu4Lz5R9JhgsQDELM16c4kEHIHZhwUsTd81igWb7wuxZ1vx1Zyto23u3gq3m2qyPqphqRqO3byuFFrqpE0F3KndHw__)

### 3.2. System Architecture Pyramid
This pyramid diagram illustrates the layered architecture of the application, showing how data flows from the storage layer up to the presentation layer.

![System Architecture Pyramid](https://private-us-east-1.manuscdn.com/sessionFile/hEvqTFxwfjACfqQbSyJTeg/sandbox/CCahtbmt50DU52xhM90PJ0-images_1780243148383_na1fn_L2hvbWUvdWJ1bnR1L3N5c3RlbV9weXJhbWlk.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvaEV2cVRGeHdmakFDZnFRYlN5SlRlZy9zYW5kYm94L0NDYWh0Ym10NTBEVTUyeGhNOTBQSjAtaW1hZ2VzXzE3ODAyNDMxNDgzODNfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzTjVjM1JsYlY5d2VYSmhiV2xrLnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=HRrYev2lpcdAxMwMngtNoH3oTcqsJj3S4gESK7tYhQWZPruFTWOS-~WtMXuveEUgFIQ-ghNzrh~I9-L119fKJyxRzltgGNiH~UGT3BSaI8oQqusQUUZ--pNjNp7k2MDl0esG6K6TpSQQitDMK0si8ORVnttv5mOPdBccfu6WomkHP-zUYe3U-tf0pvCY7f63HKbSy~qwyKkiEgC9Gd-HAZID1ordieVV5rfh2OwZVHGq12U3UfI5LqJ0iE-q2AIVSPohcUlbN89i4Ize64wbY2EXTW7j3D0k6jV6L6hQi69951BeAdwXX5UzYNUsogVJxz2rBGZBIEbEqTZh~izAQw__)

## 4. How to Run the Project
1.  Ensure Python 3 is installed on your system.
2.  Run the main application script: `python inventory_system.py`
3.  Follow the on-screen prompts to add items to your cart.
4.  Type `done` when you are finished ordering.
5.  Choose `yes` to save your receipt to a text file.
6.  To generate the 3D visual model yourself, you will need `matplotlib` and `numpy` installed (`pip install matplotlib numpy`), then run: `python visual_model.py`
